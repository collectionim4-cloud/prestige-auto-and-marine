require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Stripe = require('stripe');
const cors = require('cors');
const axios = require('axios');

const app = express();
const stripeKey = process.env.STRIPE_SECRET_KEY;
const stripe = stripeKey ? Stripe(stripeKey) : null;
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(bodyParser.json());

mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser:true, useUnifiedTopology:true })
  .then(()=>console.log('Mongo connected'))
  .catch(err=>console.error('Mongo error',err));

const BookingSchema = new mongoose.Schema({
  name:String, phone:String, vehicle:String, vin:String, vehicleType:String, datetime:Date, planKey:String, price:Number, paid:{type:Boolean,default:false}, createdAt:{type:Date,default:Date.now}
});
const Booking = mongoose.model('Booking', BookingSchema);

app.post('/api/book', async (req,res)=>{
  try{
    const { name, phone, vehicle, vin, datetime, planKey, vehicleType } = req.body;
    const priceMap = { standard:129, premier:159, exotic:199 };
    const typeMultiplier = { car:1, bike:0.6, yacht:4 };
    const base = priceMap[planKey] || 129;
    const mult = typeMultiplier[(vehicleType||'car').toLowerCase()] || 1;
    const price = Math.round(base * mult);
    const booking = await Booking.create({ name, phone, vehicle, vin, vehicleType, datetime, planKey, price });
    res.json({ id: booking._id, price });
  }catch(err){ console.error(err); res.status(500).json({ error:'db' }) }
});

app.post('/api/create-checkout-session', async (req,res)=>{
  if (!stripe) return res.status(400).json({ error: 'Stripe not configured. Connect your Stripe keys to enable payments.' });
  try{
    const { price, planKey, bookingId } = req.body;
    const domain = process.env.SITE_URL || 'http://localhost:3000';
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [{ price_data: { currency:'usd', product_data:{ name: `Inspection — ${planKey}` }, unit_amount: Math.round(price*100) }, quantity:1 }],
      success_url: `${domain}/checkout-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${domain}/checkout-canceled`,
      metadata: { bookingId }
    });
    res.json({ url: session.url });
  }catch(err){ console.error(err); res.status(500).json({ error:err.message }) }
});

const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
app.post('/api/webhook', bodyParser.raw({type:'application/json'}), async (req,res)=>{
  if (!stripe) return res.status(400).send('Stripe not configured');
  const sig = req.headers['stripe-signature'];
  let event;
  try{
    event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
  }catch(err){ console.error('Webhook signature error',err.message); return res.status(400).send(`Webhook Error: ${err.message}`); }

  if (event.type === 'checkout.session.completed'){
    const session = event.data.object;
    const bookingId = session.metadata.bookingId;
    if (bookingId){
      await Booking.findByIdAndUpdate(bookingId, { paid:true });
      console.log('Booking marked paid:', bookingId);
    }
  }
  res.json({ received:true });
});

app.get('/api/vin/:vin', async (req,res)=>{
  const vin = req.params.vin;
  try{
    const n = await axios.get(`https://vpic.nhtsa.dot.gov/api/vehicles/decodevin/${vin}?format=json`);
    res.json(n.data);
  }catch(err){ res.status(500).json({ error:'vin_fail' }) }
});

app.listen(PORT, ()=>console.log('Server running on',PORT));
