import Head from 'next/head'
import { useState, useEffect } from 'react'

const API = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:4000'

export default function Home() {
  const [booking, setBooking] = useState({ name:'', phone:'', vehicle:'', vin:'', datetime:'', vehicleType:'car' })
  const [loading, setLoading] = useState(false)
  const [slide, setSlide] = useState(0)
  const slides = ['/assets/banner-car.svg','/assets/banner-yacht.svg','/assets/banner-bike.svg']

  useEffect(()=>{ const t = setInterval(()=>setSlide(s=> (s+1)%slides.length), 5000); return ()=>clearInterval(t) },[])

  const handleCheckout = async (planKey, price) => {
    if (!process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY) {
      alert('Payments not connected yet. Please connect Stripe to accept payments.')
      return
    }
    try {
      setLoading(true)
      const bookRes = await fetch(`${API}/api/book`, {
        method: 'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ ...booking, planKey })
      })
      const bookingData = await bookRes.json()
      if (!bookingData.id) throw new Error('Booking failed')

      const res = await fetch(`${API}/api/create-checkout-session`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ price, planKey, bookingId: bookingData.id })
      })
      const data = await res.json()
      if (data.url) window.location.href = data.url
      else alert('Stripe session error')
    } catch (err) {
      console.error(err); alert('Error creating payment')
    } finally { setLoading(false) }
  }

  return (
    <div style={{background:'#061021',minHeight:'100vh',color:'#EDEDED',fontFamily:'Montserrat, Arial, sans-serif'}}>
      <Head><title>Prestige Auto & Marine</title></Head>
      <header style={{maxWidth:1200,margin:'0 auto',padding:24,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
        <div style={{display:'flex',alignItems:'center',gap:12}}>
          <img src="/assets/logo.svg" alt="logo" style={{height:64}}/>
          <div>
            <div style={{fontSize:20,fontWeight:700}}>Prestige Auto & Marine</div>
            <div style={{fontSize:12,color:'#AAB7C4'}}>Luxury Inspections • Cars • Bikes • Yachts</div>
          </div>
        </div>
        <nav>
          <a href="#plans" style={{color:'#EDEDED',marginRight:16}}>Plans</a>
          <a href="#book" style={{color:'#EDEDED'}}>Book</a>
        </nav>
      </header>

      <main style={{maxWidth:1200,margin:'0 auto',padding:24}}>
        <section style={{position:'relative',height:420,overflow:'hidden',borderRadius:16}}>
          <img src={slides[slide]} alt="banner" style={{width:'100%',height:'100%',objectFit:'cover',borderRadius:16}}/>
          <div style={{position:'absolute',left:40,top:40}}>
            <h1 style={{fontFamily:'Playfair Display, serif',fontSize:40,color:'rgb(255,211,110)',margin:0}}>Precision in Every Detail</h1>
            <p style={{color:'#DDE6EF',marginTop:8}}>Professional inspections for cars, bikes & yachts — trust the experts.</p>
          </div>
        </section>

        <section style={{display:'grid',gridTemplateColumns:'1fr 360px',gap:24,marginTop:24}}>
          <div>
            <h2 style={{color:'#FFD36E'}}>Plans</h2>
            <div style={{display:'flex',gap:12,marginTop:12}}>
              <PlanCard title="Standard" price={129} onBuy={()=>handleCheckout('standard',129)} />
              <PlanCard title="Premier" price={159} onBuy={()=>handleCheckout('premier',159)} />
              <PlanCard title="Exotic" price={199} onBuy={()=>handleCheckout('exotic',199)} />
            </div>

            <h3 style={{marginTop:20}}>Why Prestige?</h3>
            <ul style={{color:'#DDE6EF'}}>
              <li>Certified inspectors across all 50 states</li>
              <li>Comprehensive reports with photos & recommendations</li>
              <li>Specialized yacht hull & systems checks</li>
            </ul>
          </div>

          <aside id="book" style={{background:'#071028',padding:20,borderRadius:12}}>
            <h4 style={{color:'#FFD36E'}}>Book an inspection</h4>
            <form onSubmit={(e)=>e.preventDefault()}>
              <input placeholder="Full name" value={booking.name} onChange={e=>setBooking({...booking,name:e.target.value})} />
              <input placeholder="Phone" value={booking.phone} onChange={e=>setBooking({...booking,phone:e.target.value})} />
              <input placeholder="Vehicle (make model year)" value={booking.vehicle} onChange={e=>setBooking({...booking,vehicle:e.target.value})} />
              <select value={booking.vehicleType} onChange={e=>setBooking({...booking,vehicleType:e.target.value})} style={{marginTop:8}}>
                <option value="car">Car</option>
                <option value="bike">Bike</option>
                <option value="yacht">Yacht</option>
              </select>
              <input placeholder="VIN or Hull ID (optional)" value={booking.vin} onChange={e=>setBooking({...booking,vin:e.target.value})} />
              <input type="datetime-local" value={booking.datetime} onChange={e=>setBooking({...booking,datetime:e.target.value})} />
              <div style={{display:'flex',gap:8,marginTop:8}}>
                <button onClick={()=>handleCheckout('standard',129)} disabled>Pay & Book (Standard)</button>
                <button onClick={()=>handleCheckout('premier',159)} disabled>Pay & Book (Premier)</button>
              </div>
              <div style={{marginTop:8,color:'#AAB7C4'}}>Payments are disabled — connect Stripe to activate.</div>
            </form>
          </aside>
        </section>

        <footer style={{marginTop:32,padding:24,background:'#041018',borderRadius:12}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <div>
              <div style={{fontWeight:700}}>Prestige Auto & Marine</div>
              <div style={{color:'#AAB7C4'}}>support@prestigeautoandmarine.com • (555) 555-5555</div>
            </div>
            <div style={{color:'#AAB7C4'}}>© {new Date().getFullYear()} Prestige Auto & Marine</div>
          </div>
        </footer>
      </main>
    </div>
