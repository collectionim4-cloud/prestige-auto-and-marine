# Prestige Auto & Marine — Deploy-ready

This repo contains a premium dark-themed Next.js frontend and an Express backend.
Features:
- Luxury theme (dark navy + gold)
- Programmatic premium SVG logo and 3 banner slides (Car, Yacht, Bike)
- Bookings saved to MongoDB
- VIN lookup (NHTSA)
- Stripe integration present but **disabled by default**. Connect your Stripe keys to enable payments.

Quick start:
1. Install Node.js and npm.
2. Copy `.env.example` to `backend/.env` and set values.
3. In repo root: `npm install`
4. `cd frontend && npm install`
5. `cd backend && npm install`
6. Run dev servers:
   - `cd frontend && npm run dev` (port 3000)
   - `cd backend && npm start` (port 4000)

To deploy:
- Frontend: Vercel (Next.js)
- Backend: Render or Heroku
- Set environment variables on hosting provider.
